# Responsive Task Manager App using Angular

## Features
- Responsive UI
- Task creation and deletion
- Angular components and modular design
- Data binding and directives

## How to Run
1. npm install
2. ng serve

## Components
- Header
- Footer
- Task List
- Add Task
